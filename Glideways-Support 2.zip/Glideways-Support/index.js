const { 
    Client, 
    GatewayIntentBits, 
    PermissionFlagsBits, 
    EmbedBuilder, 
    Partials, 
    REST, 
    Routes, 
    SlashCommandBuilder, 
    ActionRowBuilder, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    StringSelectMenuBuilder 
} = require('discord.js');

const config = {
    token: 'MTMzNjE3NDA2ODA0NjQ5NTgxNQ.Gfp8cJ.AChqaFyuknJ_EvzdDiqw5KAPPjak2PVOrIK0G4',
    clientId: '1336174068046495815',
    GUILD_ID: '1307683399590215701',
    MODERATOR_ROLE_ID: '1323526425902317660',
    LOGGING_CHANNEL_ID: '1335403633243852820',
    CATEGORIES: {
        'Reports/Other': '1335745120599015455',
        'Affiliation Request': '1335744868424614011',
        'Department Enquiries': '1335744726271524905',
    }
};

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User],
});

// Store active tickets and restrictions
const activeTickets = new Map();
const restrictedUsers = new Set();

// Logging function
function logAction(title, description) {
    const logChannel = client.channels.cache.get(config.LOGGING_CHANNEL_ID);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
        .setColor('#90EE90')
        .setTitle(title)
        .setDescription(description)
        .setTimestamp();

    logChannel.send({ embeds: [embed] });
}

// Handle user DMs (Category Selection)
client.on('messageCreate', async (message) => {
    if (message.author.bot || message.channel.type !== 1) return;

    if (restrictedUsers.has(message.author.id)) {
        return message.reply({ content: 'You are restricted from opening tickets.', ephemeral: true });
    }

    if (activeTickets.has(message.author.id)) {
        const ticketChannel = client.channels.cache.get(activeTickets.get(message.author.id));
        if (ticketChannel) {
            await ticketChannel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#90EE90')
                        .setTitle('New Message from User')
                        .setDescription(`**${message.author.tag}:** ${message.content}`)
                        .setTimestamp()
                ]
            });
            return message.reply({ content: 'Your message has been sent to the support team.', ephemeral: true });
        }
    }

    // Show the pop-up menu
    const selectMenu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId('select_category')
            .setPlaceholder('Select a category')
            .addOptions(
                { label: 'Reports / Other', value: 'Reports/Other' },
                { label: 'Affiliation Request', value: 'Affiliation Request' },
                { label: 'Department Enquiries', value: 'Department Enquiries' }
            )
    );

    const embed = new EmbedBuilder()
        .setColor('#90EE90')
        .setTitle('Glideways Support')
        .setDescription('Why are you opening a ticket today? Please select a category below.');

    await message.reply({ embeds: [embed], components: [selectMenu] });
});

// Handle category selection
client.on('interactionCreate', async (interaction) => {
    if (interaction.isStringSelectMenu() && interaction.customId === 'select_category') {
        const selectedCategory = interaction.values[0];

        const modal = new ModalBuilder()
            .setCustomId(`ticket_reason_${selectedCategory}`)
            .setTitle('Create a Support Ticket')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('reason')
                        .setLabel('Why are you opening this ticket?')
                        .setStyle(TextInputStyle.Paragraph)
                        .setRequired(true)
                )
            );

        await interaction.showModal(modal);
    }

    // Handle modal submissions
    if (interaction.isModalSubmit() && interaction.customId.startsWith('ticket_reason_')) {
        const categoryKey = interaction.customId.split('_')[2];
        const reason = interaction.fields.getTextInputValue('reason');

        const guild = client.guilds.cache.get(config.GUILD_ID);
        if (!guild) return;

        const categoryId = config.CATEGORIES[categoryKey];
        if (!categoryId) return;

        try {
            const ticketChannel = await guild.channels.create({
                name: `ticket-${interaction.user.username}`,
                type: 0,
                topic: `Ticket opened by ${interaction.user.tag}`,
                parent: categoryId,
                permissionOverwrites: [
                    { id: interaction.user.id, allow: ['ViewChannel', 'SendMessages'] },
                    { id: guild.id, deny: ['ViewChannel'] },
                ],
            });

            activeTickets.set(interaction.user.id, ticketChannel.id);

            await ticketChannel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#90EE90')
                        .setTitle('New Support Ticket')
                        .setDescription(`**Opened by:** ${interaction.user.tag}\n\n**Reason:**\n${reason}`)
                        .setTimestamp()
                ]
            });

            logAction('Ticket Created', `**User:** ${interaction.user.tag}\n**Reason:**\n${reason}`);

            await interaction.reply({ content: `Your ticket has been created.`, ephemeral: true });

        } catch (error) {
            console.error("Error creating ticket:", error);
        }
    }
});

// Slash Commands
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isCommand()) return;

    const { commandName } = interaction;

    if (commandName === 'reply') {
        const messageContent = interaction.options.getString('message');
        const userId = [...activeTickets.entries()].find(([_, channelId]) => channelId === interaction.channel.id)?.[0];

        if (!userId) return interaction.reply({ content: 'Error: Could not find the user.', ephemeral: true });

        const user = await client.users.fetch(userId);
        await user.send({
            embeds: [
                new EmbedBuilder()
                    .setColor('#90EE90')
                    .setTitle(`Reply from ${interaction.user.username}`)
                    .setDescription(messageContent)
                    .setTimestamp()
            ]
        });

        await interaction.reply({ content: 'Reply sent.', ephemeral: true });
    } 

    else if (commandName === 'close') {
        activeTickets.delete([...activeTickets.entries()].find(([_, channelId]) => channelId === interaction.channel.id)?.[0]);
        await interaction.channel.delete();
    } 

    else if (commandName === 'restrict') {
        const user = interaction.options.getUser('user');
        restrictedUsers.add(user.id);
        await interaction.reply({ content: `${user.tag} has been restricted from opening tickets.`, ephemeral: true });
    } 

    else if (commandName === 'unrestrict') {
        const user = interaction.options.getUser('user');
        restrictedUsers.delete(user.id);
        await interaction.reply({ content: `${user.tag} can now open tickets again.`, ephemeral: true });
    }
});

// Register Slash Commands
const rest = new REST({ version: '10' }).setToken(config.token);
(async () => {
    try {
        await rest.put(Routes.applicationGuildCommands(config.clientId, config.GUILD_ID), {
            body: [
                new SlashCommandBuilder().setName('reply').setDescription('Reply to a ticket').addStringOption(opt => opt.setName('message').setDescription('Your reply').setRequired(true)),
                new SlashCommandBuilder().setName('close').setDescription('Close a support ticket'),
                new SlashCommandBuilder().setName('restrict').setDescription('Restrict a user').addUserOption(opt => opt.setName('user').setDescription('User to restrict').setRequired(true)),
                new SlashCommandBuilder().setName('unrestrict').setDescription('Unrestrict a user').addUserOption(opt => opt.setName('user').setDescription('User to unrestrict').setRequired(true))
            ]
        });
        console.log('✅ Slash commands registered.');
    } catch (error) {
        console.error('❌ Failed to register commands:', error);
    }
})();

client.once('ready', () => console.log(`✅ Logged in as ${client.user.tag}`));
client.login(config.token);